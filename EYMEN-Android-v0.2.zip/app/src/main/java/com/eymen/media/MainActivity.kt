package com.eymen.media

import android.app.Activity
import android.content.Intent
import android.content.ActivityNotFoundException
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*

/** Lightweight phone/tablet UI prototype. This is not an Android Auto video application. */
class MainActivity : Activity() {
    private val navy = Color.rgb(5, 12, 27)
    private val panel = Color.rgb(15, 28, 51)
    private val blue = Color.rgb(0, 176, 255)
    private val gold = Color.rgb(245, 192, 85)
    private lateinit var content: LinearLayout
    private var page = "Açılış"
    private val prefs by lazy { getSharedPreferences("eymen_preferences", MODE_PRIVATE) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy; window.navigationBarColor = navy
        if (savedInstanceState == null && prefs.getBoolean("intro", true)) splash() else home()
    }
    private fun background(stroke: Int = blue) = GradientDrawable().apply {
        setColor(panel); cornerRadius = dp(18).toFloat(); setStroke(dp(1), stroke)
    }
    private fun label(value: String, size: Float = 17f, tint: Int = Color.WHITE, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size; setTextColor(tint)
        setPadding(dp(12), dp(12), dp(12), dp(12))
        if (bold) typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER_VERTICAL
    }
    private fun screen(title: String) {
        page = title
        val scroll = ScrollView(this).apply { fillViewport = true; setBackgroundColor(navy) }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14),dp(12),dp(14),dp(24))
        }
        scroll.addView(content); setContentView(scroll)
        content.addView(label("♛   E Y M E N", 31f, gold, true))
        content.addView(label("Eymen Medya Kuruluşudur", 13f, blue))
        content.addView(label(title, 23f, Color.WHITE, true))
    }
    private fun tile(title: String, tint: Int = blue, action: () -> Unit): TextView = label(title, 18f, Color.WHITE, true).apply {
        gravity = Gravity.CENTER; background = background(tint)
        minHeight = dp(86); setOnClickListener { action() }
        contentDescription = title
    }
    private fun item(title: String, tint: Int = blue, action: () -> Unit) {
        val view = tile(title,tint,action)
        content.addView(view, LinearLayout.LayoutParams(-1,-2).apply { setMargins(0,dp(5),0,dp(5)) })
    }
    private fun splash() {
        page = "Açılış"
        val frame = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(navy); setPadding(dp(18),0,dp(18),0)
        }
        setContentView(frame)
        val logo = label("♛\nE  Y  M  E  N", 43f, gold, true).apply { gravity = Gravity.CENTER; alpha = 0f }
        val sub = label("Eymen Medya Kuruluşudur", 17f, blue).apply { gravity = Gravity.CENTER; alpha = 0f }
        frame.addView(logo); frame.addView(sub)
        logo.animate().alpha(1f).setDuration(650).start()
        sub.animate().alpha(1f).setStartDelay(400).setDuration(600).start()
        frame.postDelayed({ if (!isFinishing && page == "Açılış") home() }, 1700)
    }
    private fun home() {
        screen("Ana Sayfa")
        content.addView(label("Medya merkezi • Telefon / Tablet", 14f, blue))
        val services = listOf(
            Triple("▶  YouTube", "com.google.android.youtube", blue),
            Triple("♫  YouTube Music", "com.google.android.apps.youtube.music", gold),
            Triple("♪  Spotify", "com.spotify.music", blue),
            Triple("▣  Netflix", "com.netflix.mediaclient", gold),
            Triple("▣  Turkcell TV+", "com.turkcell.tvplus", blue),
            Triple("▣  Apple TV", "com.apple.atve.androidtv.appletv", gold)
        )
        val landscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val grid = GridLayout(this).apply { columnCount = if (landscape) 3 else 2 }
        content.addView(grid)
        val width = resources.displayMetrics.widthPixels / (if (landscape) 3 else 2) - dp(22)
        services.forEach { (name,pkg,tint) ->
            grid.addView(tile(name,tint) { launch(pkg,name) }, GridLayout.LayoutParams().apply {
                width = width; height = dp(100); setMargins(dp(4),dp(5),dp(4),dp(5))
            })
        }
        item("🌐  Web Tarayıcı", gold) { url("https://www.google.com") }
        item("📺  Televizyon", blue) { info("Televizyon", "Yasal yayın kaynakları daha sonra eklenecek.") }
        item("🎚  Ekolayzır", gold) { info("Ekolayzır", "Cihaza uygun ses efektleri sonraki sürümde geliştirilecek.") }
        item("⚙  Ayarlar", blue) { settings() }
        item("ⓘ  Hakkında", gold) { about() }
    }
    private fun launch(pkg: String, name: String) {
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent == null) { toast("$name yüklü değil veya bu cihazda açılamıyor."); return }
        try { startActivity(intent) } catch (_: Exception) { toast("$name açılamadı.") }
    }
    private fun url(address: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(address))) }
        catch (_: ActivityNotFoundException) { toast("Bağlantıyı açabilecek uygulama bulunamadı.") }
        catch (_: Exception) { toast("Bağlantı açılamadı.") }
    }
    private fun toast(s: String) = Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
    private fun info(title: String, message: String) {
        screen(title); content.addView(label(message)); item("← Ana Sayfa") { home() }
    }
    private fun settings() {
        screen("Ayarlar")
        item("Açılış animasyonu: " + if (prefs.getBoolean("intro",true)) "Açık" else "Kapalı") {
            prefs.edit().putBoolean("intro",!prefs.getBoolean("intro",true)).apply(); settings()
        }
        item("Ses ve Ekolayzır") { info("Ses", "Ses efektleri yalnızca Android'in izin verdiği oturumlarda kullanılabilir.") }
        item("Android Auto Durumu") { info("Android Auto", "Bu sürüm Android Auto araç ekranı uygulaması değildir; entegrasyon planlanıyor.") }
        item("Güncelleme kontrolü", gold) { url("https://github.com/mmustafatasoy/EYMEN-Android/releases") }
        item("Hakkında") { about() }
        item("← Ana Sayfa") { home() }
    }
    private fun about() {
        screen("Hakkında")
        val photo = ImageView(this).apply {
            setImageResource(R.drawable.developer_portrait)
            adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER
            contentDescription = "Muhammet Atasoy geliştirici fotoğrafı"
        }
        content.addView(photo, LinearLayout.LayoutParams(-1,dp(220)))
        content.addView(label("Muhammet Atasoy", 25f,gold,true))
        content.addView(label("EYMEN Kurucusu ve Geliştiricisi", 16f,blue))
        content.addView(label("Eymen Medya Kuruluşudur", 15f))
        item("▶ YouTube — @globalworkm") { url("https://www.youtube.com/@globalworkm") }
        item("◎ Instagram — @mmustafatasoy",gold) { url("https://www.instagram.com/mmustafatasoy/") }
        item("🌐 teknobloggs.blogspot.com") { url("https://teknobloggs.blogspot.com") }
        item("GitHub",gold) { url("https://github.com/mmustafatasoy/EYMEN-Android") }
        content.addView(label("Sürüm 0.2.0 • Geliştirme önizlemesi", 13f,blue))
        item("← Ana Sayfa") { home() }
    }
    override fun onBackPressed() { if (page == "Ana Sayfa") super.onBackPressed() else home() }
}
