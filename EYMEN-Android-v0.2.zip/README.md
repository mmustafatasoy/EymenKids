# EYMEN Android v0.2.0

**Eymen Medya Kuruluşudur** — Muhammet Atasoy.

## Özellikler
- Hafif Android yerel View arayüzü; ağır animasyon ve üçüncü taraf UI kütüphanesi yok
- Koyu lacivert, elektrik mavisi ve altın tema; dikeyde iki, yatayda üç sütunlu menü
- Kısa açılış animasyonu, ana menü, ayarlar ve geliştirici fotoğraflı Hakkında ekranı
- YouTube, YouTube Music, Spotify, Netflix, Turkcell TV+, Apple TV uygulamalarını **telefon üzerinde** açma denemesi
- Tarayıcı bağlantısı, sosyal medya bağlantıları ve GitHub Releases bağlantısı
- İnternet/konum gibi gereksiz izinler istenmez

## GitHub'a yükleme
1. ZIP'i açın. İçindeki `EYMEN-Android-v0.2` klasörünün **içindeki** dosyaları deponun köküne yükleyin.
2. GitHub Actions > Android debug APK iş akışını açın; çalışmasını bekleyin.
3. Başarılı olursa `Artifacts` bölümündeki `EYMEN-debug-apk` paketini indirin.
4. Alternatif: Android Studio > Open > proje klasörü > Sync > Build APK(s).

## Derleme gereksinimleri
Android SDK 35, JDK 17, Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Gradle 8.9.
Gradle wrapper ekli değildir; Android Studio kurulu Gradle veya GitHub Actions 8.9 kullanır.

## Sınırlar
**Bu bir Android telefon/tablet arayüz prototipidir. Android Auto ekranında video oynatmaz ve Android Auto uygulaması olarak tanıtılmaz.** Netflix/YouTube/TV+ sadece yüklü uygulamaları açmayı dener. TV, ekolayzır ve araç kontrolleri henüz tamamlanmamıştır. Performans hedefi hafifliktir; tüm cihazlarda sıfır kasma garantisi verilemez. Bu ortamda Android SDK/Gradle bulunmadığından APK derlemesi doğrulanamamıştır. GitHub Actions derleme hatası verirse günlükleri paylaşın.

## Gizlilik
Geliştirici portresi kullanıcı tarafından sağlanmıştır. Depoyu **Private** tutun. Uygulama konum veya kullanıcı hesabı bilgisi toplamaz.
